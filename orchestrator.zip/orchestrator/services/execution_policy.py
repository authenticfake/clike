from __future__ import annotations

import os
import shutil
from typing import Any, Dict

_ALLOWED_CLAUDE_PHASES = {
    "kit",
    "integrity_eval",
    "promotion_hardener",
    "promotion_eval",
}


def _env_flag(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, str(default))).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def normalize_execution_preference(value: Any) -> str:
    raw = str(value or "").strip().lower()
    allowed = {
        "auto",
        "cloud_only",
        "prefer_claude_code",
        "claude_code_only",
        "hybrid",
    }
    return raw if raw in allowed else "auto"


def resolve_execution_policy(
    *,
    phase: str,
    execution_preference: Any,
) -> Dict[str, Any]:
    pref = normalize_execution_preference(execution_preference)
    phase_norm = str(phase or "").strip().lower()

    claude_enabled = _env_flag("CLIKE_CLAUDE_CODE_ENABLED", False)
    claude_path = shutil.which("claude") if claude_enabled else None
    claude_available = bool(claude_path)
    phase_supported = phase_norm in _ALLOWED_CLAUDE_PHASES

    selected = "cloud"
    requested = pref
    eligible = False
    reason = "default_cloud"
    fallback_applied = False

    if pref == "cloud_only":
        selected = "cloud"
        eligible = False
        reason = "forced_cloud"

    elif pref == "auto":
        selected = "cloud"
        eligible = claude_available and phase_supported
        reason = "auto_prefers_current_cloud_path"

    elif pref == "prefer_claude_code":
        if phase_supported and claude_available:
            selected = "claude_code"
            eligible = True
            reason = "claude_code_preferred_and_available"
        else:
            selected = "cloud"
            eligible = False
            fallback_applied = True
            if not phase_supported:
                reason = "phase_not_supported_for_claude_code"
            elif not claude_enabled:
                reason = "claude_code_disabled"
            else:
                reason = "claude_binary_not_found"

    elif pref == "claude_code_only":
        if phase_supported and claude_available:
            selected = "claude_code"
            eligible = True
            reason = "claude_code_only_and_available"
        else:
            selected = "cloud"
            eligible = False
            fallback_applied = True
            if not phase_supported:
                reason = "phase_not_supported_for_claude_code"
            elif not claude_enabled:
                reason = "claude_code_disabled"
            else:
                reason = "claude_binary_not_found"

    elif pref == "hybrid":
        if phase_supported and claude_available:
            selected = "hybrid"
            eligible = True
            reason = "hybrid_enabled_for_phase"
        else:
            selected = "cloud"
            eligible = False
            fallback_applied = True
            if not phase_supported:
                reason = "phase_not_supported_for_hybrid_claude_path"
            elif not claude_enabled:
                reason = "claude_code_disabled"
            else:
                reason = "claude_binary_not_found"

    return {
        "requested": requested,
        "selected": selected,
        "eligible": eligible,
        "phase_supported": phase_supported,
        "claude_enabled": claude_enabled,
        "claude_available": claude_available,
        "claude_path": claude_path,
        "fallback_applied": fallback_applied,
        "reason": reason,
    }