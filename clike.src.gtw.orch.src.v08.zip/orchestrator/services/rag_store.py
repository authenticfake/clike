from __future__ import annotations
import os, re, json, time, hashlib, logging
import traceback
from typing import List, Dict, Any, Optional, Tuple
import httpx

def _rag_base_url(base_url: str | None = None) -> str:
    return (base_url or os.getenv("RAG_BASE_URL", "http://localhost:8080/v1/rag")).rstrip("/")

log = logging.getLogger("rag.store")

QDRANT_URL  = os.getenv("QDRANT_URL", "http://qdrant:6333").rstrip("/")
QCOLLECTION = os.getenv("QDRANT_COLLECTION", "clike_rag")
EMB_DIM     = int(os.getenv("EMBEDDING_DIM", "1536"))
EMB_FAMILY  = os.getenv("RAG_EMBED_FAMILY", f"emb_{EMB_DIM}")
CHUNK_TOKENS   = int(os.getenv("RAG_CHUNK_TOKENS", "800"))
CHUNK_OVERLAP  = int(os.getenv("RAG_CHUNK_OVERLAP", "80"))
TOP_K          = int(os.getenv("RAG_TOP_K", "12"))
MAX_CTX_TOKENS = int(os.getenv("RAG_MAX_CTX_TOKENS", "1800"))
MAX_EMBED_TEXT_CHARS = int(os.getenv("RAG_MAX_EMBED_TEXT_CHARS", "12000"))

TEXT_EXTS = {
    ".md",".txt",".rst",".adoc",".py",".js",".ts",".tsx",".jsx",".java",".go",".rs",
    ".cpp",".c",".h",".sql",".yml",".yaml",".json",".toml",".ini",".proto",".sh",
    ".ps1",".rb",".php",".cs",".kt"
}

def _norm_path(p: str) -> str:
    return re.sub(r"[\\]+", "/", (p or "").strip())

def _sha1(s: str) -> str:
    return hashlib.sha1(s.encode("utf-8", "ignore")).hexdigest()

def _split_chunks(text: str, tokens:int=CHUNK_TOKENS, overlap:int=CHUNK_OVERLAP) -> List[str]:
    if not text:
        return []
    unit = max(500, tokens * 4)
    step = max(256, overlap * 4)
    out = []
    i = 0
    n = len(text)
    while i < n:
        j = min(n, i + unit)
        out.append(text[i:j])
        if j == n:
            break
        i = max(i + unit - step, i + 1)
    return out


class EmbeddingClient:
    """
    Reliability-first embedding client.
    Sends one text at a time to the gateway to avoid giant batch payloads.
    Falls back to direct OpenAI only if configured.
    Does NOT generate fake/hash vectors.
    """
    def __init__(self, gateway_base: str = "http://gateway:8000/v1"):
        
        self.base = gateway_base.rstrip("/")
        self.openai_key = os.getenv("OPENAI_API_KEY")

    async def _embed_one_gateway(self, text: str) -> List[float]:
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(f"{self.base}/embeddings", json={"input": text})
            r.raise_for_status()
            data = r.json() or {}
            vecs = [d["embedding"] for d in (data.get("data") or []) if isinstance(d, dict) and "embedding" in d]
            if not vecs:
                raise RuntimeError("gateway embeddings returned no vectors")
            return vecs[0]

    async def _embed_one_openai(self, text: str) -> List[float]:
        if not self.openai_key:
            raise RuntimeError("OPENAI_API_KEY not configured")
        headers = {"Authorization": f"Bearer {self.openai_key}"}
        async with httpx.AsyncClient(timeout=30) as client:
            r = await client.post(
                "https://api.openai.com/v1/embeddings",
                headers=headers,
                json={"model": "text-embedding-3-small", "input": text},
            )
            r.raise_for_status()
            data = r.json() or {}
            vecs = [d["embedding"] for d in (data.get("data") or []) if isinstance(d, dict) and "embedding" in d]
            if not vecs:
                raise RuntimeError("openai embeddings returned no vectors")
            return vecs[0]

    async def embed(self, texts: List[str]) -> List[List[float]]:
        results: List[List[float]] = []
        for raw in texts:
            text = (raw or "")[:MAX_EMBED_TEXT_CHARS]
            if not text.strip():
                continue

            try:
                vec = await self._embed_one_gateway(text)
                results.append(vec)
                continue
            except Exception as e:
                log.warning("RAG gateway embeddings failed, trying direct OpenAI: %s", e)

            try:
                vec = await self._embed_one_openai(text)
                results.append(vec)
                continue
            except Exception as e:
                log.error("RAG embeddings failed completely: %s", e)
                raise RuntimeError(f"embeddings failed for chunk: {e}") from e

        return results

class RagStore:
    def __init__(self, project_id: str):
        # project_id → namespace: multi-progetto nello stesso Qdrant
        self.project_id = (project_id or "default")
        self.namespace = ("proj_" + re.sub(r"[^a-zA-Z0-9_]+", "_", self.project_id)).lower()
        self.q = QDRANT_URL
        self.c = f"{QCOLLECTION}__{self.namespace}__{EMB_FAMILY}"
        self.emb = EmbeddingClient()

    async def ensure(self) -> None:
        # crea collection se non esiste
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                r = await client.get(f"{self.q}/collections/{self.c}")
                if r.is_success:
                    return
                # create
                body = {
                    "vectors": {"size": EMB_DIM, "distance": "Cosine"},
                    "on_disk_payload": True,
                }
                r = await client.put(f"{self.q}/collections/{self.c}", json=body)
                r.raise_for_status()
                log.info("RAG created collection %s", self.c)
        except Exception as e:
            log.error("RAG ensure failed: %s", e)
            raise


    async def index_texts(self, items: List[Dict[str, Any]]) -> Dict[str, Any]:
        await self.ensure()

        points = []
        id_auto = int(time.time() * 1000)
        texts: List[str] = []
        metas: List[Dict[str, Any]] = []

        for it in items:
            p = _norm_path(it.get("path") or "unknown")
            t = it.get("text") or ""
            chunks = _split_chunks(t)
            for idx, ch in enumerate(chunks):
                if not ch.strip():
                    continue
                meta = {"path": p, "sha": _sha1(t), "chunk": idx}
                texts.append(ch)
                metas.append(meta)

        if not texts:
            return {"ok": True, "upserts": 0}

        try:
            vecs = await self.emb.embed(texts)
        except Exception as e:
            log.error("RAG embeddings failed before upsert: %s", e)
            return {"ok": False, "error": f"embedding failed: {e}"}

        if len(vecs) != len(metas):
            return {"ok": False, "error": f"embedding count mismatch: vecs={len(vecs)} metas={len(metas)}"}

        INCLUDE_TEXT = os.getenv("RAG_PAYLOAD_TEXT", "1").strip() not in ("0", "false", "False", "no")
        TEXT_MAX = int(os.getenv("RAG_PAYLOAD_TEXT_CHARS", "1200"))

        for i, (v, m) in enumerate(zip(vecs, metas)):
            payload = dict(m)
            if INCLUDE_TEXT:
                payload["text"] = (texts[i] or "")[:max(200, TEXT_MAX)]

            points.append({
                "id": id_auto + i,
                "vector": v,
                "payload": payload,
            })

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                body = {"points": points}
                r = await client.put(f"{self.q}/collections/{self.c}/points", json=body)
                r.raise_for_status()
            return {"ok": True, "upserts": len(points)}
        except Exception as e:
            log.error("RAG upsert failed: %s", e)
            return {"ok": False, "error": str(e)}
        

    async def search(self, query: str, top_k:int=TOP_K) -> List[Dict[str,Any]]:
        await self.ensure()
        # embed query
        vec = (await self.emb.embed([query]))[0]
        # search
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                body = {"vector": vec, "limit": top_k, "with_payload": True}
                r = await client.post(f"{self.q}/collections/{self.c}/points/search", json=body)
                r.raise_for_status()
                data = r.json()

                out = []
                for it in (data.get("result") or []):
                    pl = it.get("payload") or {}
                    out.append({
                        "path": pl.get("path",""),
                        "chunk": pl.get("chunk",0),
                        "score": it.get("score",0.0),
                        "text": pl.get("text","")
                    })
                return out
        except Exception as e:
            log.error("RAG search failed: %s", e)
            return []

    async def purge(self, path_prefix: Optional[str]=None) -> Dict[str,Any]:
        await self.ensure()
        # delete by filter
        payload_filter = {}
        if path_prefix:
            payload_filter = {"must": [{"key":"path","match":{"value":path_prefix}}]}
        try:
            async with httpx.AsyncClient(timeout=20) as client:
                body = {"filter": payload_filter} if payload_filter else {}
                r = await client.post(f"{self.q}/collections/{self.c}/points/delete", json=body)
                r.raise_for_status()
            return {"ok": True}
        except Exception as e:
            log.error("RAG purge failed: %s", e)
            return {"ok": False, "error": str(e)}
        
    async def fetch_docs_by_paths(
        self,
        paths: List[str],
        *,
        max_chars_per_doc: int = 4000,
        limit_points: int = 2000,
    ) -> List[Dict[str, Any]]:
        await self.ensure()

        wanted = [_norm_path(p) for p in (paths or []) if _norm_path(p)]
        if not wanted:
            return []

        filter_should = [{"key": "path", "match": {"value": p}} for p in wanted]

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                body = {
                    "filter": {"should": filter_should},
                    "with_payload": True,
                    "limit": max(10, int(limit_points)),
                }
                r = await client.post(f"{self.q}/collections/{self.c}/points/scroll", json=body)
                r.raise_for_status()
                data = r.json() or {}
                points = data.get("result", {}).get("points") or []

            buckets: Dict[str, Dict[str, Any]] = {}
            for pt in points:
                pl = pt.get("payload") or {}
                path = _norm_path(pl.get("path") or "")
                text = (pl.get("text") or "").strip()
                if not path or not text or path not in wanted:
                    continue

                b = buckets.get(path)
                if not b:
                    b = {"path": path, "text": "", "chunks": 0}
                    buckets[path] = b

                remaining = max_chars_per_doc - len(b["text"])
                if remaining <= 0:
                    continue

                piece = (("\n" if b["text"] else "") + text)[:remaining]
                if piece:
                    b["text"] += piece
                    b["chunks"] += 1

            out = [buckets[p] for p in wanted if p in buckets]
            return out
        except Exception as e:
            log.error("RAG fetch_docs_by_paths failed: %s", e)
            return []
