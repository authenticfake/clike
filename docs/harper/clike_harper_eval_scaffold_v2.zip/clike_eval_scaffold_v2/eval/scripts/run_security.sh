#!/usr/bin/env bash
set -euo pipefail

mkdir -p eval/out

bandit -q -r src -f json -o eval/out/bandit.json || true
