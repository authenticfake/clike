#!/usr/bin/env bash
set -euo pipefail

mkdir -p eval/out

ruff check . --output-format json > eval/out/ruff.json || true
ruff format --check . || true
mypy src > eval/out/mypy.txt || true
