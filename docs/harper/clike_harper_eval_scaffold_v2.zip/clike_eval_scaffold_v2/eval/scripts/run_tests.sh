#!/usr/bin/env bash
set -euo pipefail

mkdir -p eval/out

pytest -q --junitxml=eval/out/pytest_junit.xml --cov=src --cov-report=xml:eval/out/coverage.xml || true
