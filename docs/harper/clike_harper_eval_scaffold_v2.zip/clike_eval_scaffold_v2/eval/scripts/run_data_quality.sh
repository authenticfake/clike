#!/usr/bin/env bash
set -euo pipefail

mkdir -p eval/out

# Only run if a DQ config is present
if [ -f "eval/config/dq_orders.yaml" ] && [ -f "data/sample_orders.csv" ]; then
  python eval/scripts/run_data_quality.py --config eval/config/dq_orders.yaml --input data/sample_orders.csv --out eval/out/dq_summary.json || true
else
  echo '{"skipped": true, "reason": "DQ config or data not found"}' > eval/out/dq_summary.json
fi
