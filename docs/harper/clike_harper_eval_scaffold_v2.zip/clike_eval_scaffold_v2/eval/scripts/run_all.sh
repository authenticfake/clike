#!/usr/bin/env bash
set -euo pipefail

mkdir -p eval/out

bash eval/scripts/run_static.sh
bash eval/scripts/run_tests.sh
bash eval/scripts/run_security.sh
bash eval/scripts/run_data_quality.sh || true  # optional

python eval/runner.py --thresholds eval/config/thresholds.yaml
