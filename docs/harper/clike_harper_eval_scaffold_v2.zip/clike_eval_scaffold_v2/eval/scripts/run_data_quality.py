# Simple DQ check using pandas (comments in English).
import argparse, json, pandas as pd
from pathlib import Path
import datetime as dt

def parse_schema(cols):
    schema = {}
    for spec in cols:
        name, typ = spec.split(":")
        schema[name] = typ
    return schema

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--input", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    import yaml
    cfg = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    df = pd.read_csv(args.input)

    expected = parse_schema(cfg["expected_columns"])
    non_null = set(cfg.get("non_null", []))

    # Schema checks
    missing = [c for c in expected.keys() if c not in df.columns]
    unexpected = [c for c in df.columns if c not in expected.keys()]

    # Null ratio
    null_ratio = float(df.isna().sum().sum()) / float(df.size) if df.size else 0.0

    summary = {
        "dataset": cfg.get("dataset"),
        "row_count": int(df.shape[0]),
        "col_count": int(df.shape[1]),
        "missing_columns": missing,
        "unexpected_columns": unexpected,
        "null_ratio": null_ratio,
        "non_null_violations": {},
    }

    for col in non_null:
        if col in df.columns:
            summary["non_null_violations"][col] = int(df[col].isna().sum())

    Path(args.out).write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
