# Enterprise EVAL Pack

Focus:
- Security baseline (Bandit HIGH=0)
- Compliance proxies (PII regex scan, audit log hooks)
- Performance/SLO (latency budget on hot paths — placeholder)
- Backward-compat tests

Suggested additions:
- Dependency/license scan via `pip-licenses` or SCA tools
- Secrets scanning pre-commit/CI
