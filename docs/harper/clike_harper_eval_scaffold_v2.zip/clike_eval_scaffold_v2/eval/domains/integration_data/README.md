# Integration & Data EVAL Pack

Focus:
- Schema contracts and versioning
- Idempotency/retry semantics
- Data-quality gates (DQ)
- Backpressure & timeouts (placeholder)

Suggested additions:
- Contract tests per connector
- Great Expectations or dbt tests in data pipelines
