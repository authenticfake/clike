# Consumer EVAL Pack

Focus:
- Fast feedback for UX proxies (API latency budgets)
- Content safety hooks (policy stubs)
- Localization readiness (i18n keys present)
- Crash-free rate proxies (unit tests on critical paths)

Suggested additions:
- Snapshot tests on textual output
- Accessibility linters (if applicable)
