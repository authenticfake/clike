# Aggregates eval results and enforces thresholds.
import argparse, json, sys, yaml, xml.etree.ElementTree as ET, re
from pathlib import Path

def load_thresholds(path: str):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def load_json_count(path: Path) -> int:
    if not path.exists(): return 0
    try:
        data = json.loads(path.read_text(encoding='utf-8') or '[]')
        return len(data)
    except Exception:
        return 999999

def load_ruff_count(path: Path) -> int:
    return load_json_count(path)

def load_mypy_count(path: Path) -> int:
    if not path.exists(): return 0
    txt = path.read_text(encoding='utf-8')
    return len([ln for ln in txt.splitlines() if re.search(r"\berror:\b", ln)])

def load_pytest_failures(path: Path) -> int:
    if not path.exists(): return 0
    try:
        root = ET.fromstring(path.read_text(encoding='utf-8'))
        fails = 0
        for ts in root.iter("testsuite"):
            fails += int(ts.attrib.get("failures", 0)) + int(ts.attrib.get("errors", 0))
        return fails
    except Exception:
        return 999999

def load_coverage_ratio(path: Path) -> float:
    if not path.exists(): return 0.0
    try:
        root = ET.fromstring(path.read_text(encoding='utf-8'))
        rate = root.attrib.get("line-rate")
        if rate is not None:
            return float(rate)
        return 0.0
    except Exception:
        return 0.0

def load_bandit_high(path: Path) -> int:
    if not path.exists(): return 0
    try:
        data = json.loads(path.read_text(encoding='utf-8') or '{}')
        results = data.get("results", [])
        return sum(1 for r in results if r.get("issue_severity", "").upper() == "HIGH")
    except Exception:
        return 999999

def load_dq(path: Path):
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8') or '{}')
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--thresholds", required=True)
    args = ap.parse_args()

    thr = load_thresholds(args.thresholds)

    ruff_cnt = load_ruff_count(Path("eval/out/ruff.json"))
    mypy_cnt = load_mypy_count(Path("eval/out/mypy.txt"))
    pytest_fail = load_pytest_failures(Path("eval/out/pytest_junit.xml"))
    cov = load_coverage_ratio(Path("eval/out/coverage.xml"))
    bandit_high = load_bandit_high(Path("eval/out/bandit.json"))
    dq = load_dq(Path("eval/out/dq_summary.json"))

    summary = {
        "ruff_errors": ruff_cnt,
        "mypy_errors": mypy_cnt,
        "pytest_failures": pytest_fail,
        "coverage_ratio": cov,
        "bandit_high": bandit_high,
        "thresholds": thr,
        "gate_pass": True,
        "violations": []
    }

    # Core gates
    if ruff_cnt > thr.get("ruff_max_errors", 0):
        summary["gate_pass"] = False
        summary["violations"].append(f"ruff_errors {ruff_cnt} > {thr.get('ruff_max_errors', 0)}")

    if mypy_cnt > thr.get("mypy_max_errors", 0):
        summary["gate_pass"] = False
        summary["violations"].append(f"mypy_errors {mypy_cnt} > {thr.get('mypy_max_errors', 0)}")

    if pytest_fail > thr.get("pytest_fail_max", 0):
        summary["gate_pass"] = False
        summary["violations"].append(f"pytest_failures {pytest_fail} > {thr.get('pytest_fail_max', 0)}")

    if cov < thr.get("coverage_min", 0.0):
        summary["gate_pass"] = False
        summary["violations"].append(f"coverage_ratio {cov:.3f} < {thr.get('coverage_min', 0.0)}")

    if bandit_high > thr.get("bandit_max_sev_high", 0):
        summary["gate_pass"] = False
        summary["violations"].append(f"bandit_high {bandit_high} > {thr.get('bandit_max_sev_high', 0)}")

    # Optional data-quality gates if dq summary exists
    if dq and not dq.get("skipped"):
        null_ratio = dq.get("null_ratio", 0.0)
        schema_mismatch = len(dq.get("missing_columns", [])) + len(dq.get("unexpected_columns", []))
        if null_ratio > thr.get("dq_max_null_ratio", 1.0):
            summary["gate_pass"] = False
            summary["violations"].append(f"dq_null_ratio {null_ratio:.4f} > {thr.get('dq_max_null_ratio', 1.0)}")
        if schema_mismatch > thr.get("dq_schema_mismatch_max", 999999):
            summary["gate_pass"] = False
            summary["violations"].append(f"dq_schema_mismatch {schema_mismatch} > {thr.get('dq_schema_mismatch_max', 999999)}")

    Path("eval/out/summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    sys.exit(0 if summary["gate_pass"] else 1)

if __name__ == "__main__":
    main()
