# Eval-Driven Development (EDD) Scaffold — Cross-Domain (v2)

This scaffold is domain-agnostic and ships **EVAL Packs** for three illustrative areas:
- **Enterprise** (security, compliance, performance/SLO)
- **Consumer** (UX-quality proxies, latency, localization hooks)
- **Integration & Data** (schema contracts, idempotency, data-quality)

All comments are in English. Documents are Markdown.

## What's inside
- `eval/config/thresholds.yaml` — global gates (coverage, lint, type, security, data-quality)
- `eval/scripts/` — runners for static checks, tests+coverage, security, data-quality
- `eval/runner.py` — aggregates results and enforces thresholds
- `eval/domains/*` — domain EVAL Packs (rubrics + notes)
- `.github/workflows/clike-ci.yml` — CI pipeline with gates
- Tooling config: `ruff.toml`, `mypy.ini`, `pytest.ini`, `.coveragerc`
- `requirements-dev.txt` — dev tools (adds pandas for DQ)
- `tests/*` — placeholders for each domain
- `data/sample_orders.csv` + `eval/config/dq_orders.yaml` — example DQ inputs

## Local usage
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
export PYTHONPATH=src

bash eval/scripts/run_all.sh
```

Artifacts: `eval/out/*.json|xml`

Adjust **thresholds** in `eval/config/thresholds.yaml` and evolve domain rubrics under `eval/domains/*`.
