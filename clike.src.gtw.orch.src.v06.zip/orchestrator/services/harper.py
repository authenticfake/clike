# Phase services (SPEC/PLAN/KIT) orchestrating prompts, evals and runs.
# Iterations: each call may update documents and re-run gates.
# Branching (future): for KIT change-requests, create feature branches per request.
# Phase services (SPEC/PLAN/KIT/BUILD) orchestrating routing and gateway calls.
from __future__ import annotations
from typing import Dict, Any, Optional, List
import os, logging, time
from datetime import datetime
from services.llm_contracts import resolve_llm_selection
from config import settings

import httpx  # ensure available in requirements

GATEWAY_URL = os.environ.get("CL_GATEWAY_URL", "http://gateway:8000")
log = logging.getLogger("orcehstrator:service:harper")
TIMEOUT =float(os.environ.get("TIMEOUT", 720.0))


async def _post_json(path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    url = f"{GATEWAY_URL}{path}"
    start_time = time.time()

    log.info("POST %s keys=%s idea_md=%s core=%d atts=%d time=%.4f",
             url,
             ",".join(sorted(payload.keys())),
             bool(payload.get("idea_md")),
             len(payload.get("core") or []),
             len(payload.get("attachments") or []), start_time)
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        r = await client.post(url, json=payload)
        end_time = time.time()
        elapsed_time = end_time - start_time
        log.info(f"POST (elapsed): {elapsed_time:.4f} secondi.")


        r.raise_for_status()
        return r.json()
    
async def _normalize_message(msg: Dict[str, Any]) -> Dict[str, Any]:
    # --- Normalizzazione messages ---
    raw_msgs = msg.get("messages") or []
    norm_msgs = []
    for m in raw_msgs:
        if m is None:
            continue
        # Supporta: Pydantic model, oggetto con .dict(), o già dict
        if hasattr(m, "model_dump"):
            d = m.model_dump()
        elif hasattr(m, "dict"):
            d = m.dict()
        elif isinstance(m, dict):
            d = m
        else:
            # ignora elementi non conformi
            continue

        role = d.get("role")
        content = d.get("content")
        if isinstance(role, str) and isinstance(content, str):
            norm_msgs.append({"role": role, "content": content})

    if norm_msgs:
        msg["messages"] = norm_msgs
    else:
        # se vuoto rimuovi per lasciare al gateway la composizione di default
        msg.pop("messages", None)
    return dict(msg)

async def run_phase(phase: str, req_payload: Dict[str, Any]) -> Dict[str, Any]:
    # --- Normalizzazione in dict ---
    if hasattr(req_payload, "model_dump"):
        payload = req_payload.model_dump()   # pydantic -> dict
    elif isinstance(req_payload, dict):
        payload = dict(req_payload)          # copia difensiva
    else:
        # fallback estremo
        try:
            payload = dict(req_payload)      # tipo mapping-like
        except Exception:
            raise ValueError("Invalid request payload type for HarperService.run_phase")

    merged: Dict[str, Any] = dict(payload or {})
    merged["phase"] = phase
    merged.setdefault("cmd", phase)
    merged.setdefault("flags", {})
    merged = await _normalize_message(merged);
    if merged.get("phase") == "kit":
        kit = merged.get("kit") or {}
        targets = kit.get("targets") or []
        if not isinstance(targets, list) or len(targets) != 1 or not isinstance(targets[0], str) or not targets[0].strip():
            raise ValueError("Harper /kit requires exactly one target REQ-ID in kit.targets, e.g. { kit: { targets: ['REQ-001'] } }")

    # --- routing modello (unica fonte di verità) ---
    model_override = merged.get("model")
    profile_hint = merged.get("profileHint")

    try:
        llm_sel = await resolve_llm_selection(
            base_url=str(getattr(settings, "GATEWAY_URL", "http://localhost:8000")).rstrip("/"),
            mode="harper",
            phase=phase,
            requested_model=model_override or "auto",
            requested_provider=merged.get("provider"),
            profile_hint=profile_hint,
        )

        if llm_sel.get("model"):
            merged["model"] = llm_sel["model"]
        if llm_sel.get("provider"):
            merged["provider"] = llm_sel["provider"]
        if llm_sel.get("remote_name"):
            merged["remote_name"] = llm_sel["remote_name"]
        if llm_sel.get("profile"):
            merged["profileHint"] = llm_sel["profile"]

        merged["mode_contract"] = llm_sel.get("mode_contract") or {}

        log.info(
            "harper.routing resolved model=%s provider=%s profile=%s override=%s",
            merged.get("model"),
            merged.get("provider"),
            merged.get("profileHint"),
            model_override,
        )
        
    except Exception as e:
        log.warning("harper.routing failed (%s) → proceeding with provided model=%s", e, model_override)
    # runId di default se manca
    merged.setdefault("runId", f"{merged.get('runId')}")

    out = await _post_json("/v1/harper/run", merged)
    log.info("GATEWAY HARPER RUN RES keys=%s files=%d text=%s",
             ",".join(sorted(out.keys())),
             len(out.get("files") or []),
             "yes" if out.get("text") else "no")
    return out
