You are reading PLAN.md. Select the next N TODOs to execute:
- choose tasks with Status 'pending' and satisfied dependencies
- return them in priority order with brief execution hints
Do NOT change PLAN structure unless asked. Do NOT write code here.