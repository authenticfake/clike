You are in the KIT phase. Implement the selected TODOs from PLAN.md.
Generate artifacts (code, tests, docs) under the specified folders.
Respect SPEC constraints and follow KIT.md validation commands.
Emit diffs/patches, not vague descriptions. Keep functions typed and documented.