You are verifying a KIT build. Run the provided validation commands.
Report PASS/FAIL per step with brief diagnostics. Do NOT silently ignore failures.
If failures occur, propose minimal patches referencing files and exact lines.