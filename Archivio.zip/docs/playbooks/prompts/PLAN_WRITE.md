You are in the PLAN phase. From SPEC.md, produce a PLAN.md backlog.
Each TODO must be ≤ 2 hours, atomic, verifiable, with Priority (P1/P2/P3) and Dependencies.
Output a Markdown table with columns: ID | Description | Priority | Status | Dependencies | Notes.
Do NOT write code. Do NOT include tasks that contradict SPEC.