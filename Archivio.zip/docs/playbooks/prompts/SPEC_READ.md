You are reading SPEC.md to extract scope and constraints.
Summarize intent, constraints, non-goals, metrics, assumptions/risks.
Do NOT propose implementation or tasks. Planning happens in PLAN phase.