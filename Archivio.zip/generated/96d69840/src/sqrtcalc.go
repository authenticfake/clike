// Package sqrtcalc provides a square root calculator implemented without using
// math library primitives like math.Sqrt. It uses the Newton-Raphson (Heron)
// iterative method with configurable precision and iteration cap.
package sqrtcalc

import "errors"

// SqrtCalculator computes square roots without relying on math.Sqrt.
//
// Configuration:
//   - Tolerance: relative tolerance used for convergence (default: 1e-12 if <= 0)
//   - MaxIterations: maximum number of Newton steps (default: 100 if <= 0)
//
// Notes:
//   - Negative inputs return an error.
//   - For x == 0, the result is 0 immediately.
//   - This implementation avoids importing the math package altogether.
//
// Usage:
//   calc := sqrtcalc.New(1e-10, 50)
//   r, err := calc.Sqrt(2)
//   // r ≈ 1.414213562...
//
// The algorithm uses: g_{n+1} = 0.5 * (g_n + x / g_n)
// and stops when |g_{n+1} - g_n| <= tol * max(1, |g_{n+1}|).
type SqrtCalculator struct {
	Tolerance     float64
	MaxIterations int
}

// New constructs a SqrtCalculator with provided tolerance and max iterations.
// If tolerance <= 0, it defaults to 1e-12. If maxIterations <= 0, it defaults to 100.
func New(tolerance float64, maxIterations int) *SqrtCalculator {
	c := &SqrtCalculator{Tolerance: tolerance, MaxIterations: maxIterations}
	if c.Tolerance <= 0 {
		c.Tolerance = 1e-12
	}
	if c.MaxIterations <= 0 {
		c.MaxIterations = 100
	}
	return c
}

// Sqrt computes the square root of x using Newton's method without math.Sqrt.
// Returns an error for negative inputs or if convergence is not achieved within
// the maximum number of iterations.
func (c *SqrtCalculator) Sqrt(x float64) (float64, error) {
	if x < 0 {
		return 0, errors.New("sqrt of negative number is not defined")
	}
	if x == 0 {
		return 0, nil
	}

	// Choose a robust initial guess:
	// - For x >= 1, start at x/2 to avoid overshooting.
	// - For 0 < x < 1, start at 1 to avoid division by small numbers.
	var g float64
	if x >= 1 {
		g = x / 2
		if g == 0 { // guard (shouldn't happen for x>=1 unless subnormals)
			g = 1
		}
	} else {
		g = 1
	}

	tol := c.Tolerance
	maxIt := c.MaxIterations

	prev := g
	for i := 0; i < maxIt; i++ {
		// Newton step: g_{n+1} = 0.5 * (g_n + x / g_n)
		if g == 0 {
			// In the unlikely case g becomes zero, reset to a safer guess.
			g = 1
		}
		next := 0.5 * (g + x/g)

		// Convergence check: relative to scale of result
		if abs(next-g) <= tol*maxf(1, abs(next)) {
			return next, nil
		}

		prev = g
		g = next
	}

	// Not converged within max iterations; return best effort and an error.
	return g, errors.New("did not converge within the maximum number of iterations")
}

// abs returns the absolute value of a float64 without importing math.
func abs(v float64) float64 {
	if v < 0 {
		return -v
	}
	return v
}

// maxf returns the maximum of two float64 values without importing math.
func maxf(a, b float64) float64 {
	if a > b {
		return a
	}
	return b
}
