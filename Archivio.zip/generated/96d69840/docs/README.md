# Calcolatore di Radice Quadrata in Go (senza primitive)

Questa libreria fornisce una "classe" in Go (uno struct con metodi) per calcolare la radice quadrata senza utilizzare primitive della libreria `math` come `math.Sqrt`. L'algoritmo impiegato è il metodo iterativo di Newton-Raphson (Herone) con tolleranza e numero massimo di iterazioni configurabili.

## Caratteristiche
- Nessun utilizzo di `math.Sqrt` o funzioni analoghe.
- Tolleranza relativa configurabile per la convergenza.
- Numero massimo di iterazioni configurabile.
- Gestione dei casi speciali: valori negativi (errore), zero (risultato immediato).

## Installazione
Poiché questo è un esempio, puoi copiare il file `sqrtcalc.go` nel tuo progetto oppure inizializzare un modulo e impostare un percorso di modulo personalizzato in `go.mod`.

## Utilizzo
Esempio di utilizzo in un programma Go:

```go
package main

import (
    "fmt"
    "example.com/sqrtcalc"
)

func main() {
    // Crea un calcolatore con tolleranza 1e-10 e massimo 50 iterazioni.
    calc := sqrtcalc.New(1e-10, 50)

    // Calcola sqrt(2).
    v, err := calc.Sqrt(2)
    if err != nil {
        panic(err)
    }
    fmt.Printf("sqrt(2) = %.12f\n", v)

    // Calcola sqrt(0.0004).
    v2, err := calc.Sqrt(0.0004)
    if err != nil {
        panic(err)
    }
    fmt.Printf("sqrt(0.0004) = %.12f\n", v2)
}
```

### API
- `type SqrtCalculator struct { Tolerance float64; MaxIterations int }`
- `func New(tolerance float64, maxIterations int) *SqrtCalculator`
- `func (c *SqrtCalculator) Sqrt(x float64) (float64, error)`

Note:
- Se `tolerance <= 0` viene impostata a `1e-12`.
- Se `maxIterations <= 0` viene impostato a `100`.
- Per input negativi (`x < 0`) viene restituito un errore.

## Dettagli dell'algoritmo
Il metodo di Newton (Herone) aggiorna una stima `g` come:

```
g_{n+1} = 0.5 * (g_n + x / g_n)
```

La convergenza viene verificata confrontando la differenza tra stime successive con una tolleranza relativa:

```
|g_{n+1} - g_n| <= tol * max(1, |g_{n+1}|)
```

Questo criterio è ragionevolmente robusto per numeri grandi e piccoli.

## Immagine di esempio
Vedi `assets/sqrt_example.svg` per un'immagine che rappresenta geometricamente la radice quadrata (lato del quadrato di area x).
