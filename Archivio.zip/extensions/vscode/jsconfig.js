{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "checkJs": false,
    "allowJs": true,
    "moduleResolution": "node",
    "baseUrl": "."
  },
  "include": [
    "**/*.js",
    "webview/**/*.html",
    "webview/**/*.js"
  ],
  "exclude": [
    "node_modules",
    ".vscode-test",
    "out"
  ]
}
