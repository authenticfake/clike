from app import app  # exposes FastAPI app for `uvicorn main:app`
