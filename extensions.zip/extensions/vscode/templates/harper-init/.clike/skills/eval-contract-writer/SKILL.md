---
name: eval-contract-writer
description: Use when KIT must emit runnable test, lint, type, build, security, or runtime validation instructions.
phases: ["kit", "eval", "gate"]
lanes: ["python", "typescript", "java", "dotnet", "go", "rust", "iac", "frontend", "backend", "industrial", "ai-native"]
domains: ["consumer", "startup", "enterprise", "industrial", "manufacturing", "ai-native", "developer-tooling"]
runtime_profiles: ["local", "cloud", "local-cloud", "on-prem", "edge", "hybrid", "air-gapped"]
gate_required: true
---

# Eval Contract Writer Skill

## Intent

Every implementation REQ must produce enough execution guidance for EVAL and GATE to validate the generated work deterministically.

## Requirements

- Generate an explicit HOWTO for local execution.
- Generate or update an LTC-style execution contract when the REQ produces runnable code.
- Include exact commands for tests, lint, type checks, build checks, or runtime smoke checks when applicable.
- Mark external integration checks as opt-in.
- Document expected report paths when available.
- Avoid claiming that a check passed unless evidence exists.
- Keep commands copy-pasteable and scoped to the generated REQ.

## Evaluation

The REQ satisfies this skill only if:
- generated validation commands are concrete;
- local validation is possible when the runtime profile requires it;
- missing tools or external runners are documented clearly;
- gate expectations are traceable to commands, reports, or documented manual checks.